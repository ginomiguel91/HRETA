<?php

namespace TestFixtures;

class NotAFixture
{
}